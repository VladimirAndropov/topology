# Chess V&K



Запустите установку pygame, выполнив:  
```sh
pip install -r requirements.txt
```
Далее нужно запускать 2d_draw.py

```sh
python draw_2d.py
```

Или запуск 3d_draw.py

```sh
python draw_3d.py
```

Или запуск 4d_draw.py

```sh
python draw_3d.py
```
